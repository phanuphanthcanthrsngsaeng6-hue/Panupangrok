# NovaAgent Terminal Chat — Sandbox package

This archive contains the NovaAgent web chat application source (not the separate static UI scaffold).

## Install and start

Requires Python 3.10+ (Python 3.11 recommended). In the sandbox terminal, unzip this archive, then run:

```sh
python -m pip install -r requirements.txt
python app.py
```

Open the sandbox's published web port for **9899** (or the port shown in startup logs).

## Model configuration

`config-template.json` is sanitized and has blank credential fields. Create `config.json` from it and configure a provider/API key using the sandbox's secret manager or environment variables. Do not commit or upload `config.json`, `.env`, session files, or API keys into a public archive. A Manus bridge is optional; if using it, configure its key privately in the sandbox and run the bridge service separately.

The sandbox must expose the app's web port and keep the Python process alive. Installing dependencies alone does not make the bot run.
