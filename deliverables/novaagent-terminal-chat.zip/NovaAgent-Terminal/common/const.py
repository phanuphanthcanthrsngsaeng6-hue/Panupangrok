# Provider types
OPEN_AI = "openAI"
OPENAI = "openai"
CHATGPT = "chatGPT"  # legacy alias for OPENAI, kept for backward compatibility
BAIDU = "baidu"
QIANFAN = "qianfan"
XUNFEI = "xunfei"
CHATGPTONAZURE = "chatGPTOnAzure"
LINKAI = "linkai"
CLAUDEAPI= "claudeAPI"
QWEN = "qwen"  # legacy alias, actually routed to DashscopeBot
QWEN_DASHSCOPE = "dashscope"  # Qwen via DashScope
GEMINI = "gemini" 
ZHIPU_AI = "zhipu"  
MOONSHOT = "moonshot"
MiniMax = "minimax"
DEEPSEEK = "deepseek"
MIMO = "mimo"  # Xiaomi MiMo
MANUS = "manus"  # Manus AI
CUSTOM = "custom"  # custom OpenAI-compatible API, bot_type won't auto-switch on model change
CODEX = "codex"  # local Codex CLI (codex exec), uses the machine's own login
MODELSCOPE = "modelscope"

# Manus 2.0 models
MANUS_2_0_LITE = "manus-2.0-lite"
MANUS_2_0 = "manus-2.0"
MODELSCOPE = "modelscope"

# Model list
# Claude (Anthropic)
CLAUDE3 = "claude-3-opus-20240229"
CLAUDE_3_OPUS = "claude-3-opus-latest"
CLAUDE_3_OPUS_0229 = "claude-3-opus-20240229"
CLAUDE_3_SONNET = "claude-3-sonnet-20240229"
CLAUDE_3_HAIKU = "claude-3-haiku-20240307"
CLAUDE_35_SONNET = "claude-3-5-sonnet-latest"  # "latest" tag always points to the newest release
CLAUDE_35_SONNET_1022 = "claude-3-5-sonnet-20241022"  # dated name pinned to a specific release
CLAUDE_35_SONNET_0620 = "claude-3-5-sonnet-20240620"
CLAUDE_4_OPUS = "claude-opus-4-0"
CLAUDE_FABLE_5_1 = "claude-fable-5-1"    # Claude Fable 5.1 - alternative Claude 5 flagship
CLAUDE_FABLE_5 = "claude-fable-5"        # Claude Fable 5 - alternative Claude 5 flagship
CLAUDE_4_8_OPUS = "claude-opus-4-8"      # Claude Opus 4.8 - Agent recommended model
CLAUDE_4_7_OPUS = "claude-opus-4-7"      # Claude Opus 4.7
CLAUDE_4_6_OPUS = "claude-opus-4-6"      # Claude Opus 4.6
CLAUDE_4_SONNET = "claude-sonnet-4-0"    # Claude Sonnet 4.0
CLAUDE_4_5_SONNET = "claude-sonnet-4-5"  # Claude Sonnet 4.5 - Agent recommended model
CLAUDE_4_6_SONNET = "claude-sonnet-4-6"  # Claude Sonnet 4.6 - Agent recommended model
CLAUDE_SONNET_5 = "claude-sonnet-5"      # Claude Sonnet 5 - balanced Claude 5 flagship
CLAUDE_OPUS_5 = "claude-opus-5"          # Claude Opus 5 - previous Opus flagship
CLAUDE_OPUS_5_5 = "claude-opus-5-5"      # Claude Opus 5.5 - default flagship model for Claude

# Gemini (Google)
GEMINI_PRO = "gemini-1.0-pro"
GEMINI_15_flash = "gemini-1.5-flash"
GEMINI_15_PRO = "gemini-1.5-pro"
GEMINI_20_flash_exp = "gemini-2.0-flash-exp"  # "-exp" models are experimental and will be phased out
GEMINI_20_FLASH = "gemini-2.0-flash"  # stable release
GEMINI_25_FLASH_PRE = "gemini-2.5-flash-preview-05-20"
GEMINI_25_PRO_PRE = "gemini-2.5-pro-preview-05-06"
GEMINI_3_FLASH_PRE = "gemini-3-flash-preview"  # Gemini 3 Flash Preview - Agent recommended model
GEMINI_3_PRO_PRE = "gemini-3-pro-preview"  # Gemini 3 Pro Preview
GEMINI_31_PRO_PRE = "gemini-3.1-pro-preview"  # Gemini 3.1 Pro Preview - Agent recommended model
GEMINI_31_FLASH_LITE_PRE = "gemini-3.1-flash-lite-preview"  # Gemini 3.1 Flash Lite Preview - Agent recommended model
GEMINI_35_FLASH = "gemini-3.5-flash"  # Gemini 3.5 Flash
GEMINI_36_FLASH = "gemini-3.6-flash"  # Gemini 3.6 Flash
GEMINI_37_FLASH = "gemini-3.7-flash"  # Gemini 3.7 Flash - Agent recommended model (default)
GEMINI_38_FLASH = "gemini-3.8-flash"  # Gemini 3.8 Flash - latest flagship

# OpenAI
GPT35 = "gpt-3.5-turbo"
GPT35_0125 = "gpt-3.5-turbo-0125"
GPT35_1106 = "gpt-3.5-turbo-1106"
GPT4 = "gpt-4"
GPT4_06_13 = "gpt-4-0613"
GPT4_32k = "gpt-4-32k"
GPT4_32k_06_13 = "gpt-4-32k-0613"
GPT4_TURBO = "gpt-4-turbo"
GPT4_TURBO_PREVIEW = "gpt-4-turbo-preview"
GPT4_TURBO_01_25 = "gpt-4-0125-preview"
GPT4_TURBO_11_06 = "gpt-4-1106-preview"
GPT4_TURBO_04_09 = "gpt-4-turbo-2024-04-09"
GPT4_VISION_PREVIEW = "gpt-4-vision-preview"
GPT_4o = "gpt-4o"
GPT_4O_0806 = "gpt-4o-2024-08-06"
GPT_4o_MINI = "gpt-4o-mini"
GPT_41 = "gpt-4.1"
GPT_41_MINI = "gpt-4.1-mini"
GPT_41_NANO = "gpt-4.1-nano"
GPT_5 = "gpt-5"
GPT_5_MINI = "gpt-5-mini"
GPT_5_NANO = "gpt-5-nano"
GPT_54 = "gpt-5.4"  # GPT-5.4 - Agent recommended model
GPT_54_MINI = "gpt-5.4-mini"
GPT_54_NANO = "gpt-5.4-nano"
GPT_55 = "gpt-5.5"  # GPT-5.5 - top-tier (expensive), not default
GPT_61_SOL = "gpt-6.1-sol"      # GPT-6.1 Sol - default flagship model for GPT (Responses API)
GPT_6_LUNA = "gpt-6-luna"       # GPT-6 Luna (Responses API)
GPT_6_SOL = "gpt-6-sol"         # GPT-6 Sol (Responses API)
GPT_6_ASTRA = "gpt-6-astra"     # GPT-6 Astra - most intelligent flagship (Responses API, higher cost)
GPT_56_LUNA = "gpt-5.6-luna"    # GPT-5.6 Luna
GPT_56_TERRA = "gpt-5.6-terra"  # GPT-5.6 Terra
GPT_56_SOL = "gpt-5.6-sol"      # GPT-5.6 Sol - highest intelligence, higher latency
O1 = "o1-preview"
O1_MINI = "o1-mini"
WHISPER_1 = "whisper-1"
TTS_1 = "tts-1"
TTS_1_HD = "tts-1-hd"

# DeepSeek
DEEPSEEK_CHAT = "deepseek-chat"  # DeepSeek-V3 chat model
DEEPSEEK_REASONER = "deepseek-reasoner"  # DeepSeek-R1 model
DEEPSEEK_FLASH = "deepseek-flash"  # DeepSeek V4.1 Flash - default recommendation (native multimodal, thinking + tool calls)
DEEPSEEK_V4_FLASH = "deepseek-v4-flash"  # DeepSeek V4 Flash (thinking + tool calls)
DEEPSEEK_V4_PRO = "deepseek-v4-pro"  # DeepSeek V4 Pro - stronger on complex tasks (thinking + tool calls)
DEEPSEEK_V4_FLASH_VISION_EXP = "deepseek-v4-flash-vision-exp"  # DeepSeek V4 Flash vision (experimental, multimodal)

# Baidu Qianfan / ERNIE
ERNIE_5_1 = "ernie-5.1"  # ERNIE 5.1 - default recommendation, latest flagship
ERNIE_5 = "ernie-5.0"  # ERNIE 5.0
ERNIE_X1_1 = "ernie-x1.1"  # ERNIE X1.1 - reasoning-focused, multimodal
ERNIE_45_TURBO_128K = "ernie-4.5-turbo-128k"
ERNIE_45_TURBO_32K = "ernie-4.5-turbo-32k"
ERNIE_4_TURBO_8K = "ERNIE-4.0-Turbo-8K"
ERNIE_45_TURBO_VL = "ernie-4.5-turbo-vl"
ERNIE_45_TURBO_VL_32K = "ernie-4.5-turbo-vl-32k"

# Qwen (Alibaba Cloud DashScope)
QWEN_TURBO = "qwen-turbo"
QWEN_PLUS = "qwen-plus"
QWEN_MAX = "qwen-max"
QWEN_LONG = "qwen-long"
QWEN3_MAX = "qwen3-max"  # Qwen3 Max - Agent recommended model
QWEN35_PLUS = "qwen3.5-plus"  # Qwen3.5 Plus - Omni model (MultiModalConversation)
QWEN36_PLUS = "qwen3.6-plus"  # Qwen3.6 Plus - Omni model (MultiModalConversation)
QWEN37_PLUS = "qwen3.7-plus"  # Qwen3.7 Plus - Omni model (MultiModalConversation)
QWEN37_MAX = "qwen3.7-max"  # Qwen3.7 Max - Agent recommended model
QWEN38_MAX = "qwen3.8-max"  # Qwen3.8 Max - native effort model (multimodal endpoint)
QWEN38_FLASH = "qwen3.8-flash"  # Qwen3.8 Flash - Agent recommended model (default), 1M context / 128K output (MultiModalConversation)
QWQ_PLUS = "qwq-plus"

# MiniMax
MINIMAX_M3 = "MiniMax-M3"  # MiniMax M3 - Latest (default), native multimodal (vision)
MINIMAX_M2_7 = "MiniMax-M2.7"  # MiniMax M2.7
MINIMAX_M2_7_HIGHSPEED = "MiniMax-M2.7-highspeed"  # MiniMax M2.7 highspeed
MINIMAX_TEXT_01 = "MiniMax-Text-01"  # MiniMax Text-01
MINIMAX_ABAB6_5 = "abab6.5-chat"  # MiniMax abab6.5

# GLM (Zhipu AI)
GLM_5_3_FLASH = "glm-5.3-flash"  # GLM-5.3 Flash - Agent recommended model (default), 1M context / 128K output
GLM_5_3 = "glm-5.3"  # GLM-5.3 - Agent recommended model
GLM_5_2 = "glm-5.2"  # GLM-5.2
GLM_5_1 = "glm-5.1"  # GLM-5.1
GLM_5_TURBO = "glm-5-turbo"  # GLM-5-Turbo
GLM_5 = "glm-5"  # GLM-5
GLM_5V_TURBO = "glm-5v-turbo"  # Zhipu multimodal (vision)
GLM_4 = "glm-4"
GLM_4_PLUS = "glm-4-plus"
GLM_4_flash = "glm-4-flash"
GLM_4_LONG = "glm-4-long"
GLM_4_ALLTOOLS = "glm-4-alltools"
GLM_4_0520 = "glm-4-0520"
GLM_4_AIR = "glm-4-air"
GLM_4_AIRX = "glm-4-airx"
GLM_4_7 = "glm-4.7"  # GLM-4.7 - Agent recommended model

# Kimi (Moonshot)
MOONSHOT = "moonshot"
KIMI_K3 = "kimi-k3"  # Kimi K3 - Agent recommended model (default)
KIMI_K2_7_CODE = "kimi-k2.7-code"  # Kimi K2.7 Code
KIMI_K2_7_CODE_HIGHSPEED = "kimi-k2.7-code-highspeed"  # Kimi K2.7 Code highspeed
KIMI_K2 = "kimi-k2"
KIMI_K2_5 = "kimi-k2.5"
KIMI_K2_6 = "kimi-k2.6"

# Xiaomi MiMo
MIMO_V2_5_PRO = "mimo-v2.5-pro"      # MiMo V2.5 Pro - flagship, long context (default recommendation)
MIMO_V2_5 = "mimo-v2.5"              # MiMo V2.5 - multimodal (text/image/audio/video)
MIMO_V2_PRO = "mimo-v2-pro"          # MiMo V2 Pro
MIMO_V2_OMNI = "mimo-v2-omni"        # MiMo V2 Omni - multimodal
MIMO_V2_FLASH = "mimo-v2-flash"      # MiMo V2 Flash - high-speed

# Doubao (Volcengine Ark)
DOUBAO = "doubao"
DOUBAO_SEED_2_1_PRO = "doubao-seed-2-1-pro-260628"
DOUBAO_SEED_2_1_TURBO = "doubao-seed-2-1-turbo-260628"
DOUBAO_SEED_2_CODE = "doubao-seed-2-0-code-preview-260215"
DOUBAO_SEED_2_PRO = "doubao-seed-2-0-pro-260215"
DOUBAO_SEED_2_LITE = "doubao-seed-2-0-lite-260215"
DOUBAO_SEED_2_MINI = "doubao-seed-2-0-mini-260215"

# ModelScope
QWEN3_235B_A22B_INSTRUCT_2507 = "Qwen/Qwen3-235B-A22B-Instruct-2507"
QWEN3_5_27B = "Qwen/Qwen3.5-27B"

# Other models
WEN_XIN = "wenxin"
WEN_XIN_4 = "wenxin-4"
XUNFEI = "xunfei"
LINKAI_35 = "linkai-3.5"
LINKAI_4_TURBO = "linkai-4-turbo"
LINKAI_4o = "linkai-4o"
MODELSCOPE = "modelscope"

GITEE_AI_MODEL_LIST = ["Yi-34B-Chat", "InternVL2-8B", "deepseek-coder-33B-instruct", "InternVL2.5-26B", "Qwen2-VL-72B", "Qwen2.5-32B-Instruct", "glm-4-9b-chat", "codegeex4-all-9b", "Qwen2.5-Coder-32B-Instruct", "Qwen2.5-72B-Instruct", "Qwen2.5-7B-Instruct", "Qwen2-72B-Instruct", "Qwen2-7B-Instruct", "code-raccoon-v1", "Qwen2.5-14B-Instruct"]

MODELSCOPE_MODEL_LIST = ["deepseek-ai/DeepSeek-R1-0528", "deepseek-ai/DeepSeek-R1-Distill-Llama-70B", "deepseek-ai/DeepSeek-R1-Distill-Llama-8B", "deepseek-ai/DeepSeek-R1-Distill-Qwen-1.5B", "deepseek-ai/DeepSeek-R1-Distill-Qwen-14B", "deepseek-ai/DeepSeek-R1-Distill-Qwen-32B",
                         "deepseek-ai/DeepSeek-R1-Distill-Qwen-7B", "deepseek-ai/DeepSeek-V3.2", "LLM-Research/c4ai-command-r-plus-08-2024", "LLM-Research/Llama-4-Maverick-17B-128E-Instruct", "meituan-longcat/LongCat-Flash-Lite", "MiniMax/MiniMax-M1-80k", "MiniMax/MiniMax-M2.5", "mistralai/Ministral-8B-Instruct-2410",
                         "mistralai/Mistral-Large-Instruct-2407", "mistralai/Mistral-Small-Instruct-2409", "moonshotai/Kimi-K2.5", "MusePublic/Qwen-Image-Edit", "opencompass/CompassJudger-1-32B-Instruct", "OpenGVLab/InternVL3_5-241B-A28B",
                         "Qwen/QVQ-72B-Preview", "Qwen/Qwen-Image-Edit", "Qwen/Qwen3-0.6B", "Qwen/Qwen3-1.7B", "Qwen/Qwen3-14B", "Qwen/Qwen3-235B-A22B", "Qwen/Qwen3-235B-A22B-Instruct-2507", "Qwen/Qwen3-235B-A22B-Thinking-2507", "Qwen/Qwen3-30B-A3B", "Qwen/Qwen3-30B-A3B-Thinking-2507",
                         "Qwen/Qwen3-32B", "Qwen/Qwen3-4B", "Qwen/Qwen3-8B", "Qwen/Qwen3-Coder-30B-A3B-Instruct", "Qwen/Qwen3-Coder-480B-A35B-Instruct", "Qwen/Qwen3-Next-80B-A3B-Instruct", "Qwen/Qwen3-Next-80B-A3B-Thinking", "Qwen/Qwen3-VL-235B-A22B-Instruct", "Qwen/Qwen3-VL-8B-Instruct",
                         "Qwen/Qwen3-VL-8B-Thinking", "Qwen/Qwen3.5-122B-A10B", "Qwen/Qwen3.5-27B", "Qwen/Qwen3.5-35B-A3B", "Qwen/Qwen3.5-397B-A17B", "Qwen/QwQ-32B", "Qwen/QwQ-32B-Preview", "Shanghai_AI_Laboratory/Intern-S1", "Shanghai_AI_Laboratory/Intern-S1-mini",
                         "stepfun-ai/Step-3.5-Flash", "XiaomiMiMo/MiMo-V2-Flash", "ZhipuAI/GLM-4.7-Flash", "ZhipuAI/GLM-5"]


MODEL_LIST = [
              # DeepSeek
              DEEPSEEK_FLASH, DEEPSEEK_V4_FLASH, DEEPSEEK_V4_PRO, DEEPSEEK_CHAT, DEEPSEEK_REASONER,

              # Baidu Qianfan / ERNIE
              QIANFAN, ERNIE_5_1, ERNIE_5, ERNIE_X1_1, ERNIE_45_TURBO_128K, ERNIE_45_TURBO_32K, ERNIE_4_TURBO_8K,
              ERNIE_45_TURBO_VL, ERNIE_45_TURBO_VL_32K,

              # MiniMax
              MiniMax, MINIMAX_M3, MINIMAX_M2_7, MINIMAX_M2_7_HIGHSPEED, MINIMAX_ABAB6_5,

              # Xiaomi MiMo
              MIMO, MIMO_V2_5_PRO, MIMO_V2_5, MIMO_V2_PRO, MIMO_V2_OMNI, MIMO_V2_FLASH,

              # Claude
              CLAUDE_OPUS_5_5, CLAUDE_OPUS_5, CLAUDE_SONNET_5, CLAUDE_FABLE_5_1, CLAUDE_FABLE_5, CLAUDE3, CLAUDE_4_8_OPUS, CLAUDE_4_7_OPUS, CLAUDE_4_6_SONNET, CLAUDE_4_6_OPUS, CLAUDE_4_OPUS, CLAUDE_4_5_SONNET, CLAUDE_4_SONNET, CLAUDE_3_OPUS, CLAUDE_3_OPUS_0229,
              CLAUDE_35_SONNET, CLAUDE_35_SONNET_1022, CLAUDE_35_SONNET_0620, CLAUDE_3_SONNET, CLAUDE_3_HAIKU,
              "claude", "claude-3-haiku", "claude-3-sonnet", "claude-3-opus", "claude-3.5-sonnet",

              # Gemini
              GEMINI_38_FLASH, GEMINI_37_FLASH, GEMINI_36_FLASH, GEMINI_35_FLASH, GEMINI_31_FLASH_LITE_PRE, GEMINI_31_PRO_PRE, GEMINI_3_PRO_PRE, GEMINI_3_FLASH_PRE, GEMINI_25_PRO_PRE, GEMINI_25_FLASH_PRE,
              GEMINI_20_FLASH, GEMINI_20_flash_exp, GEMINI_15_PRO, GEMINI_15_flash, GEMINI_PRO, GEMINI,

              # OpenAI
              GPT35, GPT35_0125, GPT35_1106, "gpt-3.5-turbo-16k",
              GPT4, GPT4_06_13, GPT4_32k, GPT4_32k_06_13,
              GPT4_TURBO, GPT4_TURBO_PREVIEW, GPT4_TURBO_01_25, GPT4_TURBO_11_06, GPT4_TURBO_04_09,
              GPT_4o, GPT_4O_0806, GPT_4o_MINI,
              GPT_41, GPT_41_MINI, GPT_41_NANO,
              GPT_61_SOL, GPT_6_LUNA, GPT_6_SOL, GPT_6_ASTRA,
              GPT_56_LUNA, GPT_56_TERRA, GPT_56_SOL,
              GPT_5, GPT_5_MINI, GPT_5_NANO,
              GPT_54, GPT_55, GPT_54_MINI, GPT_54_NANO,
              O1, O1_MINI,

              # GLM (Zhipu AI)
              ZHIPU_AI, GLM_5_3_FLASH, GLM_5_3, GLM_5_2, GLM_5_1, GLM_5_TURBO, GLM_5, GLM_4, GLM_4_PLUS, GLM_4_flash, GLM_4_LONG, GLM_4_ALLTOOLS,
              GLM_4_0520, GLM_4_AIR, GLM_4_AIRX, GLM_4_7,

              # Qwen
              QWEN38_FLASH, QWEN37_PLUS, QWEN37_MAX, QWEN38_MAX, QWEN36_PLUS, QWEN35_PLUS, QWEN3_MAX, QWEN_MAX, QWEN_PLUS, QWEN_TURBO, QWEN_LONG,

              # Doubao
              DOUBAO, DOUBAO_SEED_2_1_PRO, DOUBAO_SEED_2_1_TURBO,
              DOUBAO_SEED_2_CODE, DOUBAO_SEED_2_PRO, DOUBAO_SEED_2_LITE, DOUBAO_SEED_2_MINI,

              # Kimi (Moonshot)
              MOONSHOT, "moonshot-v1-8k", "moonshot-v1-32k", "moonshot-v1-128k",
              KIMI_K3, KIMI_K2_7_CODE, KIMI_K2_7_CODE_HIGHSPEED, KIMI_K2_6, KIMI_K2_5, KIMI_K2,

              # ModelScope
              MODELSCOPE,

              # LinkAI
              LINKAI_35, LINKAI_4_TURBO, LINKAI_4o,

              # Other models
              WEN_XIN, WEN_XIN_4, XUNFEI,
            ]

MODEL_LIST = MODEL_LIST + GITEE_AI_MODEL_LIST + MODELSCOPE_MODEL_LIST

# Fallback model when `model` is missing from the config. Keep in sync with
# config-template.json so a config without an explicit model behaves the same
# as a fresh install.
DEFAULT_MODEL = DEEPSEEK_FLASH

# channel
FEISHU = "feishu"
DINGTALK = "dingtalk"
WECOM_BOT = "wecom_bot"
QQ = "qq"
WEIXIN = "weixin"
WECHAT_KF = "wechat_kf"
TELEGRAM = "telegram"
SLACK = "slack"
DISCORD = "discord"
LINE = "line"
